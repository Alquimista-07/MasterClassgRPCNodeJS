# gRPC NodeJS

![Udemy](.github/badges/udemy.svg)

## COUPON: `START_AUG`

## Build

### Arm

```
npm_config_target_arch=x64 npm install
```

### Not Arm

```
npm install
```
